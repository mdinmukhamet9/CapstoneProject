#ifndef MPC_CONTROLLER_HPP_
#define MPC_CONTROLLER_HPP_

#include <memory>
#include <string>

#include "nav2_core/controller.hpp"
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist_stamped.hpp"
#include "nav_msgs/msg/path.hpp"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"
#include "tf2_ros/buffer.h"
#include "acados_solver_holder.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "visualization_msgs/msg/marker.hpp"  // Changed to Marker

namespace mpc_low
{

class MPCController : public nav2_core::Controller
{
public:
    MPCController();
    ~MPCController() override = default;

    void configure(
        const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
        std::string name,
        const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) override;

    void cleanup() override;
    void activate() override;
    void deactivate() override;

    geometry_msgs::msg::TwistStamped computeVelocityCommands(
        const geometry_msgs::msg::PoseStamped & pose,
        const geometry_msgs::msg::Twist & velocity,
        nav2_core::GoalChecker * goal_checker) override;

    void setPlan(const nav_msgs::msg::Path & path) override;
    void setSpeedLimit(const double & speed_limit, const bool & percentage) override;
    void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg);
    void publishGoalMarker(const geometry_msgs::msg::PoseStamped& goal_pose);
    void publishFinalGoalMarker(const geometry_msgs::msg::PoseStamped& goal_pose);

protected:
    nav_msgs::msg::Path transformGlobalPlan(const geometry_msgs::msg::PoseStamped & pose);

    bool transformPose(
        const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::string frame,
        const geometry_msgs::msg::PoseStamped & in_pose,
        geometry_msgs::msg::PoseStamped & out_pose,
        const rclcpp::Duration & transform_tolerance);

    rclcpp_lifecycle::LifecycleNode::WeakPtr node_;
    std::shared_ptr<tf2_ros::Buffer> tf_;
    std::string plugin_name_;
    rclcpp::Logger logger_{rclcpp::get_logger("MPCController")};
    rclcpp::Clock::SharedPtr clock_;

    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
    nav_msgs::msg::Path global_plan_;
    rclcpp::Duration transform_tolerance_;
    double desired_linear_vel_;
    double max_angular_vel_;
    int nmpc_horizon_steps_;
    geometry_msgs::msg::PoseStamped prev_selected_goal_pose_;
    bool prev_goal_valid_ = false;

    std::unique_ptr<my_NMPC_solver> nmpc_solver_;
    rclcpp_lifecycle::LifecyclePublisher<nav_msgs::msg::Path>::SharedPtr global_pub_;
    rclcpp_lifecycle::LifecyclePublisher<nav_msgs::msg::Path>::SharedPtr traj_pub_;

    rclcpp_lifecycle::LifecyclePublisher<visualization_msgs::msg::Marker>::SharedPtr marker_pub_;  // Changed to Marker

    // Added for velocity smoothing
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
    rclcpp::Time last_marker_publish_time_;
    int marker_id_counter_;
    double marker_publish_interval_;
    // Add after existing members
    int max_obstacles_;
    double weight_x_;
    double weight_y_; 
    double weight_yaw_;
    double weight_terminal_x_;
    double weight_terminal_y_;
    double weight_terminal_;
    double blend_factor_;
    double prev_linear_vel_;
    double prev_angular_vel_;
    int publish_counter_;  // Added missing member
    double wheel_base_;  // Added member variable for wheel base
    rclcpp_lifecycle::LifecyclePublisher<visualization_msgs::msg::Marker>::SharedPtr goal_marker_pub_;
    double r_wheel_;  // Wheel radius
    double alpha_;    // Scaling factor for angular velocity
    double B_;  // Distance between wheels
    double tracking_goal_[30];  // Added member variable for tracking_goal
};

}  // namespace mpc_low

#endif  // MPC_CONTROLLER_HPP_